import java.util.Scanner;

public class Main {

    public static void main(String args[]) {

        Estacionamiento e = new Estacionamiento();
        Scanner sc = new Scanner(System.in);
        String decision1;
        int decision2;
        boolean estado1 = true;
        boolean estado2 = true;
        boolean estado3 = true;
        boolean estado4 = true;
        boolean estado5 = true;
        boolean estado6 = true;
        boolean estado7 = true;
        boolean estado8 = true;
        boolean estado9 = true;
        boolean estado10 = true;
        e.agregarAutos();

        boolean a = true;
        boolean b = true;
        System.out.println("Bienvenido a HERTZ");

        while (a == true) {

            System.out.println("DESEA ARRENDAR UNO DE NUESTROS AUTOS? (Ingrese si/no)");
            decision1 = sc.nextLine();

            if (decision1.equals("si")) {
                e.mostrarAutos();
                decision2 = sc.nextInt();
                b = true;
                while (b == true) {

                    if (decision2 == 1) {
                        if (estado1 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(0).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(0).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(0).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 1");
                            estado1 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 2) {
                        if (estado2 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(1).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(1).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(1).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 2");
                            estado2 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 3) {
                        if (estado3 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(2).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(2).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(2).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 3");
                            estado3 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 4) {
                        if (estado4 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(3).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(3).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(3).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 4");
                            estado4 = false;
                            b = false;
                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 5) {
                        if (estado5 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(4).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(4).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(4).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 5");
                            estado5 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 6) {
                        if (estado6 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(5).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(5).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(5).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 6");
                            estado6 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 7) {
                        if (estado7 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(6).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(6).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(6).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 7");
                            estado1 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 8) {
                        if (estado8 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(7).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(7).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(7).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 8");
                            estado8 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 9) {
                        if (estado9 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(8).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(8).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(8).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 9");
                            estado9 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }
                    if (decision2 == 10) {
                        if (estado10 == true) {
                            System.out.println("Usted a arrendado un auto marca: " + e.getAutos().get(9).getNombre()
                                    + ", con capacidad de combustible " + e.getAutos().get(9).getEstanque()
                                    + " litros con kilometraje " + e.getAutos().get(9).getEstanque()
                                    + " por favor al termino de su jornada estacionar/devolver"
                                    + "el automovil en el lugar 10");
                            estado10 = false;
                            b = false;

                        } else {
                            System.out.println("El auto ya esta arrendado");
                            b = false;
                        }
                    }


                }


            }


        }
    }
}












