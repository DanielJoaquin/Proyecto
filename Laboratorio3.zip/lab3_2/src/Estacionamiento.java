import java.util.ArrayList;

public class Estacionamiento {

    private ArrayList<Auto> autos = new ArrayList<Auto>();





    Auto a1 = new Auto("Peugeot 207", 40);
    Auto a2 = new Auto("Mazda 2", 20);
    Auto a3 = new Auto("Jeep Full", 60);


    void agregarAutos(){

        for(int i=0; i<10; i++){

            int r = (int) (Math.random()*3)+1;

            if (r == 1){
                autos.add(a1);
            }
            else if(r==2){
                autos.add(a2);
            }
            else{
                autos.add(a3);
            }

        }

    }

    void mostrarAutos(){

        System.out.println("-----------------------------------------------------------------");
        System.out.println("Que Auto desea Arrendar?");
        int posicion = 1;

        for ( Auto a : autos) {

            System.out.println("<"+posicion+ ">" + " Marca: " + a.getNombre());

            posicion = posicion + 1;
        }
        System.out.println("-----------------------------------------------------------------");
    }


    public ArrayList<Auto> getAutos() {
        return autos;
    }

    public void setAutos(ArrayList<Auto> autos) {
        this.autos = autos;
    }
}
