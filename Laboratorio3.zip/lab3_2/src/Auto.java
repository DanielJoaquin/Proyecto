public class Auto {

    private String nombre;
    private double estanque;
    private double kilometraje;



    public Auto(String nombre, double estanque) {
        this.nombre = nombre;
        this.estanque = estanque;

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getEstanque() {
        return estanque;
    }

    public void setEstanque(double estanque) {
        this.estanque = estanque;
    }

    public double getKilometraje() {

        int r = (int) (Math.random()*2000);
        kilometraje = r;
        return kilometraje;
    }

    public void setKilometraje(double kilometraje) {
        this.kilometraje = kilometraje;
    }


}
