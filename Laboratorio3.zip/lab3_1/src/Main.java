public class Main {

    public static void main (String arg[]){

        Prueba p = new Prueba();

        p.agregarPreguntas();
        p.mostrarPreguntas();
        p.agregarAotraLista();
        p.mostrarPrueba();

    }
}
