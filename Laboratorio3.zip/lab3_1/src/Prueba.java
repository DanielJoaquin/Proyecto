import java.util.ArrayList;
import java.util.Scanner;

public class Prueba {

    Preguntas pre;
    private ArrayList<Preguntas> preguntas = new ArrayList<>();
    private ArrayList<Preguntas> prueba = new ArrayList<>();

    Scanner sc = new Scanner(System.in);
    String p;   //Pregunta
    int cantPreguntas;
    Preguntas quiz;
    String a;
    void agregarPreguntas(){

        System.out.println("Cuantas preguntas va a ingresar?: ");
        cantPreguntas = sc.nextInt();
        if(cantPreguntas>=5) {
            for (int i = 0; i <= cantPreguntas; i++) {
                System.out.println("Agregue la pregunta: ");
                p = sc.nextLine();

                pre = new Preguntas(p);

                preguntas.add(pre);

            }
        }
        else{
            System.out.println("No puede, ingrese una cantidad mayor o igual a 5");
        }

    }

    void mostrarPreguntas(){

        for (Preguntas pre:
             preguntas) {
            System.out.println(pre.getNombrePregunta());
        }

    }

    void agregarAotraLista(){

        for(int x=0;x<5;x++){

            int r = (int)(Math.random()*cantPreguntas);

            a = preguntas.get(r).getNombrePregunta();


            quiz = new Preguntas(a);

            prueba.add(quiz);


        }



    }
    void mostrarPrueba(){

        for(int x=0;x<=prueba.size();x++){
            System.out.println(prueba.get(x).getNombrePregunta());
        }

    }









}
