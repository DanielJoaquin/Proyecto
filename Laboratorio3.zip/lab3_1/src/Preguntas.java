import java.util.ArrayList;

public class Preguntas {

    private String nombrePregunta;

    public Preguntas(String nombrePregunta) {
        this.nombrePregunta = nombrePregunta;
    }

    public String getNombrePregunta() {
        return nombrePregunta;
    }

    public void setNombrePregunta(String nombrePregunta) {
        this.nombrePregunta = nombrePregunta;
    }




}
